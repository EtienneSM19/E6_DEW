# DEW2024-Ex6
Examen DEW 2024-2025 Tema 5 y 6 AJAX y Almacenamiento local: Proyecto / Tareas
